/*
 *  MetaDL 0.1 - metalink downloading plugin for NSIS
 *  Copyright (c) 2007 Hampus Wessman (hw@vox.nu)
 *  
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <windows.h>
#include <commctrl.h>
#include <string.h>
#include <stdio.h>
#include <curl/curl.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include "exdll.h"
#include "md5.h"
#include "sha1.h"
#include "metalink.h"

#define DLL_EXPORT __declspec(dllexport)

/* Code from the NSISdl plugin (lightly modified) */

HMODULE     hModule;
HWND        g_hwndProgressBar;
HWND        g_hwndStatic;
static int  g_cancelled;
static void *lpWndProcOld;

HWND g_hwndParent;

static UINT uMsgCreate;

HWND childwnd;
HWND hwndL;
HWND hwndB;

static LRESULT CALLBACK ParentWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (uMsgCreate && message == uMsgCreate)
    {
        static HWND hwndPrevFocus;
        static BOOL fCancelDisabled;

        if (wParam)
        {
            childwnd = FindWindowEx((HWND) lParam, NULL, "#32770", NULL);
            hwndL = GetDlgItem(childwnd, 1016);
            hwndB = GetDlgItem(childwnd, 1027);
            HWND hwndP = GetDlgItem(childwnd, 1004);
            HWND hwndS = GetDlgItem(childwnd, 1006);
            if (childwnd && hwndP && hwndS)
            {
                /* Where to restore focus to before we disable the cancel button */
                hwndPrevFocus = GetFocus();
                if (!hwndPrevFocus)
                  hwndPrevFocus = hwndP;

                if (IsWindowVisible(hwndL))
                  ShowWindow(hwndL, SW_HIDE);
                else
                  hwndL = NULL;
                if (IsWindowVisible(hwndB))
                  ShowWindow(hwndB, SW_HIDE);
                else
                  hwndB = NULL;

                RECT wndRect, ctlRect;

                GetClientRect(childwnd, &wndRect);

                GetWindowRect(hwndS, &ctlRect);

                HWND s = g_hwndStatic = CreateWindow(
                  "STATIC",
                  "",
                  WS_CHILD | WS_CLIPSIBLINGS | SS_CENTER,
                  0,
                  wndRect.bottom / 2 - (ctlRect.bottom - ctlRect.top) / 2,
                  wndRect.right,
                  ctlRect.bottom - ctlRect.top,
                  childwnd,
                  NULL,
                  hModule,
                  NULL
                );

                DWORD dwStyle = WS_CHILD | WS_CLIPSIBLINGS;
                dwStyle |= GetWindowLong(hwndP, GWL_STYLE) & PBS_SMOOTH;

                GetWindowRect(hwndP, &ctlRect);

                HWND pb = g_hwndProgressBar = CreateWindow(
                  "msctls_progress32",
                  "",
                  dwStyle,
                  0,
                  wndRect.bottom / 2 + (ctlRect.bottom - ctlRect.top) / 2,
                  wndRect.right,
                  ctlRect.bottom - ctlRect.top,
                  childwnd,
                  NULL,
                  hModule,
                  NULL
                );

                long c;

                c = SendMessage(hwndP, PBM_SETBARCOLOR, 0, 0);
                SendMessage(hwndP, PBM_SETBARCOLOR, 0, c);
                SendMessage(pb, PBM_SETBARCOLOR, 0, c);

                c = SendMessage(hwndP, PBM_SETBKCOLOR, 0, 0);
                SendMessage(hwndP, PBM_SETBKCOLOR, 0, c);
                SendMessage(pb, PBM_SETBKCOLOR, 0, c);

                /* set font */
                long hFont = SendMessage((HWND) lParam, WM_GETFONT, 0, 0);
                SendMessage(pb, WM_SETFONT, hFont, 0);
                SendMessage(s, WM_SETFONT, hFont, 0);

                ShowWindow(pb, SW_SHOWNA);
                ShowWindow(s, SW_SHOWNA);

                fCancelDisabled = EnableWindow(GetDlgItem(hwnd, IDCANCEL), TRUE);
                SendMessage(hwnd, WM_NEXTDLGCTL, (WPARAM)GetDlgItem(hwnd, IDCANCEL), TRUE);
            }
            else
                childwnd = NULL;
        }
        else if (childwnd)
        {
            if (hwndB)
            {
                ShowWindow(hwndB, SW_SHOWNA);
                hwndB = NULL;
            }
            if (hwndL)
            {
                ShowWindow(hwndL, SW_SHOWNA);
                hwndL = NULL;
            }

            /* Prevent wierd stuff happening if the cancel button happens to be
               pressed at the moment we are finishing and restore the previous focus
               and cancel button states */
            SendMessage(hwnd, WM_NEXTDLGCTL, (WPARAM)hwndPrevFocus, TRUE);
            SendMessage(GetDlgItem(hwnd, IDCANCEL), BM_SETSTATE, FALSE, 0);
            if (fCancelDisabled)
                EnableWindow(GetDlgItem(hwnd, IDCANCEL), FALSE);

            if (g_hwndStatic)
            {
                DestroyWindow(g_hwndStatic);
                g_hwndStatic = NULL;
            }
            if (g_hwndProgressBar)
            {
                DestroyWindow(g_hwndProgressBar);
                g_hwndProgressBar = NULL;
            }
            childwnd = NULL;
        }
    }
    else if (message == WM_COMMAND && LOWORD(wParam) == IDCANCEL)
    {
        g_cancelled = 1;
    }
    else
    {
        return CallWindowProc(
          (WNDPROC) lpWndProcOld,
          hwnd,
          message,
          wParam,
          lParam
        );
    }
    return 0;
}


static double g_file_size;
static DWORD g_dwLastTick = 0;
void progress_callback(char *msg, double read_bytes)
{
    /* flicker reduction by A. Schiffler */
    DWORD dwLastTick = g_dwLastTick;
    DWORD dwThisTick = GetTickCount();
    if (childwnd)
    {
        if (dwThisTick - dwLastTick > 500)
        {
            SetWindowText(g_hwndStatic, msg);
            dwLastTick = dwThisTick;
        }
        if(g_file_size > 0)
            SendMessage(g_hwndProgressBar, PBM_SETPOS, (WPARAM) (read_bytes*30000/g_file_size), 0);
        g_dwLastTick = dwLastTick;
    }
}

/* Code mostly written by Hampus Wessman (some parts are inspired by, or taken from, NSISdl) */

char *error = 0;
double g_startsize = 0;
double g_downloaded = 0;

/* Stores some general settings and some data about the current download */
typedef struct {
    char szDownloading[1024];  /* = "Downloading %s"; */
    char szConnecting[1024];   /* = "Connecting to %s..."; */
    char szInitializing[1024]; /* = "Initializing download..."; */
    char szChecksums[1024];    /* = "Calculating checksums..."; */
    char szRetrying1[1024];    /* = "Retrying in %d seconds... (%d of %d)"; */
    char szRetrying2[1024];    /* = "Retrying in %d seconds..."; */
    char szSecond[1024];       /* = "second"; */
    char szPlural[1024];       /* = "s"; */
    char szProgress[1024];     /* = "%s (%d%%) of %s @ %s/s"; */
    char szRemaining[1024];    /* = " (%s remaining)"; */
    char proxy[1024];
    int timeout_ms;
    int retry_time;
    int max_tries;
    int hash_tries;
    DWORD start_time;
    hashdata hashes;
} download_data;

/* Mirrorlist structures */
typedef struct mirrorinfo {
    char *url;
    int errors;
    int time_since;
    struct mirrorinfo *next;
} mirrorinfo;

typedef struct {
    int length;
    mirrorinfo *first;
    mirrorinfo *last;
} mirrorlist;

mirrorlist* mirrorlist_create()
{
    mirrorlist *list = (mirrorlist*) calloc(1, sizeof(mirrorlist));
    if(list == 0) return 0;
    return list;
}

void mirrorlist_add(mirrorlist *list, char *url)
{
    mirrorinfo *item = (mirrorinfo*) malloc(sizeof(mirrorinfo));
    if(item != 0) {
        item->url = (char*) malloc(strlen(url)+1);
        item->errors = 0;
        item->time_since = 0;
        item->next = 0;
        strcpy(item->url, url);
        
        if(list->length == 0) {
            list->first = item;
            list->last = item;
        } else {
            list->last->next = item;
            list->last = item;
        }
        list->length++;
    }
}

void mirrorlist_free(mirrorlist *list)
{
    int i;
    mirrorinfo *item = list->first;
    mirrorinfo *next;
    for(i = 0; i < list->length; i++)  {
        next = item->next;
        free(item->url);
        free(item);
        item = next;
    }
    free(list);
}

void write_log(char *buf)
{
    FILE *f = fopen("log.txt", "ab");
    fwrite(buf, strlen(buf), sizeof(char), f);
    fwrite("\n", strlen("\n"), sizeof(char), f);
    fclose(f);
}

char* rstrstr(char *str1, char *str2)
{
    char *match = str1, *last_match = 0;
    while(1)
    {
        match = strstr(match, str2);
        if(match == 0) break;
        last_match = match;
        match += 1;
    }
    return last_match;
}

size_t write_data(void *buffer, size_t size, size_t nmemb, FILE *f)
{
    write_log("write_data");
    int wrote = fwrite(buffer, size, nmemb, f);
    g_downloaded += (double) wrote;
    char buf[1024];
    sprintf(buf, "wrote=%d, g_downloaded=%.0f", wrote, g_downloaded);
    write_log(buf);
    write_log("returning from write_data\n");
    if(g_cancelled) return 0;
    return wrote;
}

void generate_hexdigest(unsigned char *digest, int length, char **hexptr)
{
    char hexbuf[3];
    char *hexdigest;
    int i;
    /* Convert the hash to hex */
    hexdigest = (char*) malloc(length*2+1);
    memset(hexdigest, '\0', length*2+1);
    for(i = 0; i < length; i++) {
        sprintf(hexbuf, "%02x", digest[i]);
        strncat(hexdigest, hexbuf, 2);
    }
    /* Return the hexdigest and success (0 = success) */
    *hexptr = hexdigest;
}

static int file_hash(char *filename, char **md5ptr, char **sha1ptr, download_data *dldata)
{
    unsigned char md5digest[16];
    unsigned char sha1digest[20];
    struct stat filestat;
    FILE *f;
    size_t n;
    md5_context md5ctx;
    sha1_context sha1ctx;
    unsigned char buf[1024];
    double readbytes = 0;
    
    /* Check the file size (for progress info) */
    if(stat(filename, &filestat) == 0) {
        g_file_size = filestat.st_size;
    } else {
        g_file_size = 0;
    }
    progress_callback(dldata->szChecksums, 0);
    
    /* Generate the hashes */
    f = fopen(filename, "rb");
    if(f == 0) return 1;
    md5_starts(&md5ctx);
    sha1_starts(&sha1ctx);
    while(1)
    {
        n = fread(buf, 1, sizeof(buf), f);
        if(n <= 0) break;
        if(g_cancelled) {
            fclose(f);
            error = "cancel";
            return 1;
        }
        readbytes += n;
        progress_callback(dldata->szChecksums, readbytes);
        md5_update(&md5ctx, buf, (int)n);
        sha1_update(&sha1ctx, buf, (int)n);
    }
    fclose(f);
    md5_finish(&md5ctx, md5digest);
    sha1_finish(&sha1ctx, sha1digest);
    
    /* Convert the hashes to hex */
    generate_hexdigest(md5digest, 16, md5ptr);
    generate_hexdigest(sha1digest, 20, sha1ptr);
        
    /* Return success */
    return 0;
}

static int check_file(char *filename, hashdata hashes, download_data *dldata)
{
    int failure;
    char buf[1024];
    char *md5hash, *sha1hash;
    
    sprintf(buf, "Checking file %s", filename);
    write_log(buf);
    
    /* Generate hashes */
    if(hashes.has_md5 || hashes.has_sha1) {
        failure = file_hash(filename, &md5hash, &sha1hash, dldata);
        if(failure) return 1;
    }
    
    /* Check a md5 hash */
    if(hashes.has_md5) {
        sprintf(buf, "MD5: %s %s", md5hash, hashes.md5);
        write_log(buf);
        failure = strcasecmp(md5hash, hashes.md5);
        free(md5hash);
        if(failure) return 1;
    }
    
    /* Check a sha1 hash */
    if(hashes.has_sha1) {
        sprintf(buf, "SHA1: %s %s", sha1hash, hashes.sha1);
        write_log(buf);
        failure = strcasecmp(sha1hash, hashes.sha1);
        free(sha1hash);
        if(failure) return 1;
    }
    write_log("File check successful!\n");
    return 0;
}

#define GIGABYTE 1073741824
#define MEGABYTE 1048576
#define KILOBYTE 1024

int curl_progress(download_data *dldata, double dltotal, double dlnow, double ultotal, double ulnow)
{
    char buf[1024];
    sprintf(buf, "curl_progress dlnow=%.0f, dltotal=%.0f", dlnow, dltotal);
    write_log(buf);
    double size = dltotal + g_startsize;
    double sofar = dlnow + g_startsize;
    double divsize;
    g_file_size = size;
    if(size < dlnow) size = dlnow;
    divsize = size;
    if(divsize < 1) divsize = 1;
    double time_sofar = (double)(GetTickCount() - dldata->start_time)/1000;
    double bps = (sofar-g_startsize)/(time_sofar>1?time_sofar:1);
    int rhours = 0, rmins = 0;
    int remain;
    if(sofar-g_startsize > 0) {
        remain = (int)(time_sofar*(size-g_startsize)/(sofar-g_startsize) - time_sofar);
    } else {
        remain = -1;
    }
    
    char str_size[100];
    char str_sofar[100];
    char str_bps[100];
    char str_remain[100];
    
    if(remain < 0) {
        remain = -1;
    } else if (remain >= 60) {
        rmins = remain/60;
        remain = remain % 60;
        if (rmins >= 60)
        {
            rhours = rmins/60;
            rmins = rmins % 60;
            sprintf(str_remain, "%d:%02d:%02d", rhours, rmins, remain);
        } else {
            sprintf(str_remain, "%d:%02d", rmins, remain);
        }
    } else {
        sprintf(str_remain, "%d %s%s", remain, dldata->szSecond, remain==1?"":dldata->szPlural);
    }
    
    if(sofar >= GIGABYTE) {
        sprintf(str_sofar, "%.2f GB", (float)sofar/GIGABYTE);
    } else if(sofar >= MEGABYTE) {
        sprintf(str_sofar, "%.1f MB", (float)sofar/MEGABYTE);
    } else if(sofar >= KILOBYTE) {
        sprintf(str_sofar, "%.0f kB", sofar/KILOBYTE);
    } else {
        sprintf(str_sofar, "%.0f bytes", sofar);
    }
    if(size >= GIGABYTE) {
        sprintf(str_size, "%.2f GB", (float)size/GIGABYTE);
    } else if(size >= MEGABYTE) {
        sprintf(str_size, "%.1f MB", (float)size/MEGABYTE);
    } else if(size >= KILOBYTE) {
        sprintf(str_size, "%.0f kB", size/KILOBYTE);
    } else {
        sprintf(str_size, "%.0f bytes", size);
    }
    if(bps >= GIGABYTE) {
        sprintf(str_bps, "%.2f GB", (float)bps/GIGABYTE);
    } else if(bps >= MEGABYTE) {
        sprintf(str_bps, "%.1f MB", (float)bps/MEGABYTE);
    } else if(bps >= KILOBYTE) {
        sprintf(str_bps, "%.0f kB", bps/KILOBYTE);
    } else {
        sprintf(str_bps, "%.0f bytes", bps);
    }
    sprintf (buf,
          dldata->szProgress,
          str_sofar,
          (int)(100*sofar/divsize),
          str_size,
          str_bps
          );
    if(remain != -1) {
        sprintf(buf+strlen(buf),dldata->szRemaining, str_remain);
    }
    write_log("progress_callback");
    progress_callback(buf, sofar);
    write_log("returning from curl_progress\n");
    return g_cancelled;
}

/* Returns an int from 0 to num-1 */
int rand_index(int num)
{
    return rand() % num;
}

/* Returns the "best" mirror to try */
mirrorinfo* choose_mirror(mirrorlist *mirrors)
{
    mirrorinfo *mirror;
    mirrorinfo *chosen;
    int i;
    int min_error, num_best;
    int max_time;
    /* Find the best servers and count them */
    mirror = mirrors->first;
    min_error = mirror->errors;
    num_best = 0;
    max_time = 0;
    while(mirror) {
        mirror->time_since++;
        if(mirror->errors == min_error && mirror->time_since == max_time) {
            num_best++;
        } else if(mirror->errors == min_error && mirror->time_since > max_time) {
            min_error = mirror->errors;
            max_time = mirror->time_since;
            num_best = 1;
        } else if(mirror->errors < min_error) {
            min_error = mirror->errors;
            max_time = mirror->time_since;
            num_best = 1;
        }
        mirror = mirror->next;
    }
    /* Choose one of the best mirrors randomly */
    i = rand_index(num_best);
    mirror = mirrors->first;
    chosen = mirror;
    while(mirror) {
        if(mirror->errors == min_error && mirror->time_since == max_time) {
            if(i == 0) chosen = mirror;
            i--;
        }
        /* Keep the 'errors' down, so we can run forever! */
        mirror->errors -= min_error;
        /* Continue with the next mirror */
        mirror = mirror->next;
    }
    chosen->time_since = 0;
    char buf[1024];
    sprintf(buf, "Mirror: %s", chosen->url);
    write_log(buf);
    return chosen;
}

/* Downloads file
 * returns 0 on success, 1 on error.
 */
int download_file(CURL *curl_handle, mirrorlist *mirrors, char *filename, download_data *dldata)
{
    char buf[1024];
    char filename_partial[1024];
    char *url;
    char *match;
    char host[1024];
    static char curlerror[CURL_ERROR_SIZE];
    struct stat filestat;
    mirrorinfo *mirror;
    int tries = 1;
    int hash_tries = 1;
    long response;
    int i;
    FILE *f;
    sprintf(filename_partial, "%s.partial", filename);
    
    /* Check if the file already exists */
    if(stat(filename, &filestat) == 0) {
        /* File already exists */
        if(check_file(filename, dldata->hashes, dldata) == 0) {
            /* It's the right file - no need to download it again */
            return 0;
        } else {
            if(g_cancelled) {
                error = "cancel";
                return 1;
            }
            /* Remove the old file. We need the right file instead! */
            if(remove(filename)) {
                error = "Could not remove an old file.";
                return 1;
            }
        }
    }
    
    /* Check for a partial download */
    if(stat(filename_partial, &filestat) == 0) {
        g_startsize = filestat.st_size;
    } else {
        g_startsize = 0;
    }
    g_downloaded = g_startsize;
    
    /* Create or append to partial download file */
    f = fopen(filename_partial, "ab" );
    if(!f) {
        sprintf(buf, "Unable to open %s", filename);
        error = buf;
        return 1;
    }
    
    while(1) {
        /* Choose a mirror to try */
        mirror = choose_mirror(mirrors);
        url = mirror->url;
        
        /* Init the download */
        sprintf(buf, "Init download: url='%s', g_startsize=%.0f, proxy='%s'", url, g_startsize, dldata->proxy);
        write_log(buf);
        curl_easy_setopt(curl_handle, CURLOPT_URL, url);
        curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_data);
        curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, f);
        curl_easy_setopt(curl_handle, CURLOPT_FOLLOWLOCATION, 1);
        curl_easy_setopt(curl_handle, CURLOPT_MAXREDIRS, 5);
        curl_easy_setopt(curl_handle, CURLOPT_AUTOREFERER, 1);
        curl_easy_setopt(curl_handle, CURLOPT_NOPROGRESS, 0);
        curl_easy_setopt(curl_handle, CURLOPT_PROGRESSFUNCTION, curl_progress);
        curl_easy_setopt(curl_handle, CURLOPT_PROGRESSDATA, dldata);
        curl_easy_setopt(curl_handle, CURLOPT_ERRORBUFFER, curlerror);
        curl_easy_setopt(curl_handle, CURLOPT_RESUME_FROM_LARGE, (curl_off_t)g_startsize);
        curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "MetaDL/0.1 libcurl/7.16.1 (NSIS plugin)");
        curl_easy_setopt(curl_handle, CURLOPT_PROXY, dldata->proxy);
        /*curl_easy_setopt(curl_handle, CURLOPT_TIMEOUT, dldata->timeout_ms / 1000);
        curl_easy_setopt(curl_handle, CURLOPT_CONNECTTIMEOUT, dldata->timeout_ms / 1000);*/
        dldata->start_time = GetTickCount();
        
        /* Display connect message */
        match = strstr(url+7, "/");
        if(match == url) {
            i = strlen(url);
        } else {
            i = match - url + 1;
        }
        memset(host, '\0', sizeof(host));
        strncpy(host, url, i);
        sprintf(buf, dldata->szConnecting, host);
        SetWindowText(g_hwndStatic, buf);
        
        /* Perform the download*/
        sprintf(buf, "Starting download: %s\n", url);
        write_log(buf);
        CURLcode failed = curl_easy_perform(curl_handle);
        sprintf(buf, "Download returned: %d %s\n", failed, curlerror);
        write_log(buf);
        CURLcode info_code = curl_easy_getinfo(curl_handle, CURLINFO_RESPONSE_CODE,  &response);
        if(info_code == CURLE_OK) {
            if(response >= 400) {
                /* We don't want this erronous data! */
                sprintf(buf, "Response code: %d truncating to %.0f\n", (int)response, g_startsize);
                write_log(buf);
                fflush(f);
                failed = ftruncate(fileno(f), (long)g_startsize);
                if(failed != 0) {
                    error = "Could not truncate file!";
                    return 1;
                }
                g_downloaded = g_startsize;
                if(fseek(f, 0, SEEK_END)) {
                    error = "fseek() failed!";
                    return 1;
                }
                failed = 1;
            }
        }
        if(failed) {
            if(g_cancelled) {
                error = "cancel";
                return 1;
            } else {
                /* Remember this failure */
                mirror->errors++;
                /* Should we try again? */
                tries++;
                if(tries > dldata->max_tries && dldata->max_tries > 0) {
                    fclose(f);
                    error = curlerror;
                    return 1;
                }
                /* Try to resume the downloading again */
                g_startsize = g_downloaded;                
                /* Wait for some time before retrying (we don't want to overload the servers!) */
                if(dldata->max_tries > 0) {
                    sprintf(buf, dldata->szRetrying1, dldata->retry_time, tries-1, dldata->max_tries-1);
                } else {
                    sprintf(buf, dldata->szRetrying2, dldata->retry_time);
                }
                SetWindowText(g_hwndStatic, buf);
                for(i = 0; i < dldata->retry_time*10; i++) {
                    if(g_cancelled) {
                        error = "cancel";
                        return 1;
                    }
                    Sleep(100);
                }
            }
        } else {
            /* Done with the download! */
            fclose(f);
            /* Checksum checking */
            if(check_file(filename_partial, dldata->hashes, dldata))
            {
                if(g_cancelled) {
                    error = "cancel";
                    return 1;
                }
                /* Check failed - file is corrupt! */
                hash_tries++;
                /* Register this as an error on the current mirror (we don't know, but we would prefer another now!) */
                mirror->errors++;
                /* Delete the corrupted file */
                remove(filename_partial);
                /* Make another try? */
                if(hash_tries <= dldata->hash_tries || dldata->hash_tries == 0) {
                    /* Start from the beginning */
                    g_startsize = 0;
                    g_downloaded = g_startsize;
                    /* Create a partial download file */
                    f = fopen(filename_partial, "ab" );
                    if(!f) {
                        sprintf(buf, "Unable to open %s", filename);
                        error = buf;
                        return 1;
                    }
                    /* Reset tries. This is considered as a new download. */
                    tries = 1;
                    /* Wait for some time before retrying (we don't want to overload the servers!) */
                    if(dldata->hash_tries > 0) {
                        sprintf(buf, dldata->szRetrying1, dldata->retry_time, hash_tries-1, dldata->hash_tries-1);
                    } else {
                        sprintf(buf, dldata->szRetrying2, dldata->retry_time);
                    }
                    SetWindowText(g_hwndStatic, buf);
                    for(i = 0; i < dldata->retry_time*10; i++) {
                        if(g_cancelled) {
                            error = "cancel";
                            return 1;
                        }
                        Sleep(100);
                    }
                } else {
                    error = "Hash check failed!";
                    return 1;
                }
            } else {
                /* Rename file */
                if(rename(filename_partial, filename)) {
                    error = "Could not rename file.";
                    return 1;
                }
                /* Success! */
                return 0;
            }
        }
    }
}

void DLL_EXPORT download(HWND parent, int string_size,
                    char *variables, stack_t **stacktop,
                    extra_parameters *extra)
{
    char buf[1024];
    char filename[1024];
    int getieproxy = 1;
    int manualproxy = 0;
    int state, failure;
    metalink *ml = 0;
    mirrorlist *mirrors = mirrorlist_create();
    if(mirrors == 0) {
        pushstring("Out of memory!");
        return;
    }
    int i;
    
    download_data dldata;
    dldata.timeout_ms = 30000;
    dldata.max_tries = 0;
    dldata.hash_tries = 0;
    dldata.retry_time = 5;
    dldata.hashes.has_md5 = 0;
    dldata.hashes.has_sha1 = 0;
    strcpy(dldata.proxy, "");
    int translated = 0;

    g_hwndParent = parent;
    curl_global_init(CURL_GLOBAL_ALL);
    EXDLL_INIT();
    srand(time(0));

    /* Parse arguments */
    state = 0;
    while(state != 2)
    {
        failure = popstring(buf);
        if(failure) break;
        switch(state)
        {
            /* State 0 reads options and eventually an url */
            case 0:
                if (!strcmp(buf, "/TRANSLATE")) {
                    popstring(dldata.szDownloading);
                    popstring(dldata.szConnecting);
                    popstring(dldata.szInitializing);
                    popstring(dldata.szChecksums);
                    popstring(dldata.szRetrying1);
                    popstring(dldata.szRetrying2);
                    popstring(dldata.szSecond);
                    popstring(dldata.szPlural);
                    popstring(dldata.szProgress);
                    popstring(dldata.szRemaining);
                    translated = 1;
                } else if (!strncmp(buf, "/TIMEOUT=", 9)) {
                    dldata.timeout_ms = atoi(buf+9);
                } else if (!strncmp(buf, "/MAXTRIES=", 10)) {
                    dldata.max_tries = atoi(buf+10);
                } else if (!strncmp(buf, "/HASHTRIES=", 11)) {
                    dldata.hash_tries = atoi(buf+11);
                } else if (!strncmp(buf, "/RETRYTIME=", 11)) {
                    dldata.retry_time = atoi(buf+11);
                } else if (!strcmp(buf, "/MD5")) {
                    popstring(buf);
                    if(strlen(buf) == 32) {
                        strcpy(dldata.hashes.md5, buf);
                        dldata.hashes.has_md5 = 1;
                    } else {
                        error = "Invalid MD5 hash!";
                        break;
                    }
                } else if (!strcmp(buf, "/SHA1")) {
                    popstring(buf);
                    if(strlen(buf) == 40) {
                        strcpy(dldata.hashes.sha1, buf);
                        dldata.hashes.has_sha1 = 1;
                    } else {
                        error = "Invalid SHA1 hash!";
                        break;
                    }
                } else if (!strcmp(buf, "/PROXY")) {
                    getieproxy = 0;
                    manualproxy = 1;
                    popstring(dldata.proxy);
                } else if (!strcmp(buf, "/NOIEPROXY")) {
                    getieproxy = 0;
                } else if (!strncmp(buf, "/MIRRORS=", 9)) {
                    int num_mirrors = atoi(buf+9);
                    for(i = 0; i < num_mirrors; i++) {
                        popstring(buf);
                        mirrorlist_add(mirrors, buf);
                    }
                } else if (!strncmp(buf, "/", 1)) {
                    /* Unknown option = not good! */
                    error = "Unknown option!";
                    break;
                } else {
                    /* This is the URL! */
                    mirrorlist_add(mirrors, buf);
                    state = 1;
                }
                break;
            /* In state 1 we expect to find a filename in buf */
            case 1:
                strcpy(filename, buf);
                state = 2;
                break;
        }
    }
    if(!translated) {
        strcpy(dldata.szDownloading, "Downloading %s");
        strcpy(dldata.szConnecting, "Connecting to %s...");
        strcpy(dldata.szInitializing, "Initializing download...");
        strcpy(dldata.szChecksums, "Calculating checksums...");
        strcpy(dldata.szRetrying1, "Retrying in %d seconds... (%d of %d)");
        strcpy(dldata.szRetrying2, "Retrying in %d seconds...");
        strcpy(dldata.szSecond, "second");
        strcpy(dldata.szPlural, "s");
        strcpy(dldata.szProgress, "%s (%d%%) of %s @ %s/s");
        strcpy(dldata.szRemaining, " (%s remaining)");
    }
    if(state != 2) {
        error = "Failed to parse arguments.";
    }
    
    /* Init progress view */
    if (parent)
    {
        uMsgCreate = RegisterWindowMessage("nsisdl create");

        lpWndProcOld = (void *)SetWindowLong(parent,GWL_WNDPROC,(long)ParentWndProc);

        SendMessage(parent, uMsgCreate, TRUE, (LPARAM) parent);

        /* set initial text */
        char *p = filename;
        while (*p) p++;
        while (*p != '\\' && p != filename) p = CharPrev(filename, p);
        wsprintf(buf, dldata.szDownloading, p != filename ? p + 1 : p);
        SetDlgItemText(childwnd, 1006, buf);
        SetWindowText(g_hwndStatic, dldata.szInitializing);
        /* Init progress bar */
        SendMessage(g_hwndProgressBar, PBM_SETRANGE, 0, MAKELPARAM(0, 30000));
    }
    
    if(!error) {
        /* Create curl handle */
        CURL *curl_handle = curl_easy_init();
        
        /* Download the file */
        failure = download_file(curl_handle, mirrors, filename, &dldata);
        if(!failure) {
            error = "success";
            /* Check if we downloaded a metalink. If so - read it! */
            if(ends_with(filename, ".metalink")) {
                ml = metalink_parse_file(filename);
            }
        }
        
        /* Cleanup curl handle */
        curl_easy_cleanup(curl_handle);
        
        /* If a metalink was read, download those files too */
        if(ml) {
            metafile *file = ml->first_file;
            while(file) {
                /* Prepare the download */
                char *match = rstrstr(filename, "\\");
                if(match == 0) {
                    match = filename;
                } else {
                    match += 1;
                }
                strcpy(match, file->filename);
                /* Copy the hashes */
                memcpy(&dldata.hashes, &file->hashes, sizeof(hashdata));
                /* Add all the mirrors */
                mirrorlist_free(mirrors);
                mirrors = mirrorlist_create();
                metamirror *mirror = file->first_mirror;
                while(mirror) {
                    mirrorlist_add(mirrors, mirror->url);
                    mirror = mirror->next;
                }
                /* Set initial text */
                char *p = filename;
                while (*p) p++;
                while (*p != '\\' && p != filename) p = CharPrev(filename, p);
                wsprintf(buf, dldata.szDownloading, p != filename ? p + 1 : p);
                SetDlgItemText(childwnd, 1006, buf);
                SetWindowText(g_hwndStatic, dldata.szInitializing);
                /* Create curl handle */
                CURL *curl_handle = curl_easy_init();
                /* Make the download */
                failure = download_file(curl_handle, mirrors, filename, &dldata);
                if(!failure) {
                    error = "success";
                } else {
                    break;
                }
                /* Cleanup curl handle */
                curl_easy_cleanup(curl_handle);
                /* Go on to the next file */
                file = file->next;
            }
            metalink_free(ml);
        }
    }
    
    /* Cleanup mirrorlist */
    mirrorlist_free(mirrors);
    
    /* Cleanup progress view */
    if (parent)
    {
        SendMessage(parent, uMsgCreate, FALSE, (LPARAM) parent);
        SetWindowLong(parent, GWL_WNDPROC, (long)lpWndProcOld);
    }
    /* Return a result on the stack */
    pushstring(error);
    /* Clean up after curl */
    curl_global_cleanup();
}

void DLL_EXPORT download_quiet(HWND parent, int string_size,
                    char *variables, stack_t **stacktop,
                    extra_parameters *extra)
{
    g_hwndParent = parent;
    g_hwndProgressBar = 0;
    download(0, string_size, variables, stacktop, 0);
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    hModule = hinstDLL;
    return TRUE;
}
