Note that if you run this test installer and then uninstalls the
"Test" app, you will still need to delete the downloaded files
manually from the disk.

Please take into consideration that bandwidth isn't free...