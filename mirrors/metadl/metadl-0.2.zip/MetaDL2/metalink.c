/*
 *  MetaDL 0.2 - metalink downloading plugin for NSIS
 *  Copyright (c) 2007 Hampus Wessman (hw@vox.nu)
 *  
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdio.h>
#include <string.h>
#include <expat.h>
#include <ctype.h>
#include <windows.h>
#include "metalink.h"

void addstring(char **str, char *str2)
{
	char *str1 = *str;
	char *str3;
	if(str1 == 0) str1 = "";
	str3 = (char *)calloc(strlen(str1) + strlen(str2) + 1,  sizeof(char));
	strcat(str3, str1);
	strcat(str3, str2);
	if(*str != 0) free(*str);
	*str = str3;
}

char* trim(char *str)
{
	char *buf;
	int len = strlen(str), begin = -1, end = 0, i;
	for(i = 0; i < len; i++) {
		if(!isspace((int)str[i])) {
			if(begin == -1) begin = i;
			end = (len-1) - i;
		}
	}
	if(begin < 0) begin = 0;
	len = len-begin-end;
	buf = calloc(len+1, sizeof(char));
	strncpy(buf, str+begin, len);
	free(str);
	return buf;
}

int ends_with(char *str, char *str_end)
{
	char *str1;
	int len1 = strlen(str), len2 = strlen(str_end);
	if(len1 < len2) return 0;
	str1 = str + len1 - len2;
	if(!strcasecmp(str1, str_end)) {
		return 1;
	} else {
		return 0;
	}
}

typedef struct parsedata {
	int state; /* What is happening right now? How are things going? */
	int depth; /* How deep in the tree are we? */
	int read_text; /* 0 = don't read this, otherwise indicates what we are reading right now (a hash, file name or similar...) */
	metalink *ml; /* The metalink to be filled in with the data */
	metafile *file; /* Current file - we add mirrors and hashes to this one */
	metamirror *mirror; /* Current mirror */
	int hash_type; /* 1 = md5, 2 = sha1 */
	int check_protocol; /* 0 = already done (with the 'type' attr), 1 = check the URL. Some basic checking will happen in any case. */
	char *file_size; /* Temporary storage of the file size, while parsing */
	XML_Parser parser; /* The expat parser */
} parsedata;

/*
STATES:
0 = error
1 = ready
2 = success
3 = parsing 'metalink' (or anything inside the metalink tag)
4 = parsing 'file' (we are inside a 'file' tag!)
5 = parsing hashes (we are inside 'verification')
6 = parsing piece hashes (inside 'piece')
7 = parsing resources

READ_TEXT:
0 = don't read any characters
1 = identity
2 = hash (for the whole file)
3 = url
4 = file size
*/

void XMLCALL start(void *userData, const char *el, const char **attr) {
	int i;
	parsedata *data = userData;
	if(data->state == 0) return;
	data->depth++;
	switch(data->state)
	{
		/* Ready */
		case 1:
			if(!strcasecmp(el, "metalink")) {
				data->state = 3; /* We are now parsing the metalink */
				/* Check the version, so that it is supported (ie '3.0') */
				for (i = 0; attr[i]; i += 2) {
					if(!strcasecmp(attr[i], "version")) {
						if(strcasecmp(attr[i+1], "3.0")) {
							data->state = 0; /* error - wrong version! */
							XML_StopParser(data->parser, XML_FALSE);
							return;
						}
						break; /* We found what we were looking for */
					}
				}
			}
			break;
		/* Metalink */
		case 3:
			if(!strcasecmp(el, "identity")) data->read_text = 1;
			if(!strcasecmp(el, "file")) {
				/* Check the name (must be there for the file to be valid) */
				for (i = 0; attr[i]; i += 2) {
					if(!strcasecmp(attr[i], "name")) {
						data->state = 4; /* Now parsing a 'file' */
						metafile *file = create_metafile();
						file->filename = calloc(strlen(attr[i+1]), sizeof(char));
						strcpy(file->filename, attr[i+1]);
						metalink_add_file(data->ml, file); /* Add the new file (without any urls so far) */
						data->file = file; /* Set this as the current file (so that file info will be added to this one) */
						break;
					}
				}
			}
			break;
		/* File */
		case 4:
			if(!strcasecmp(el, "size")) {
				/* Reading file size */
				data->read_text = 4;
				if(data->file_size) free(data->file_size);
				data->file_size = 0;
				addstring(&data->file_size, "");
			}
			if(!strcasecmp(el, "verification")) data->state = 5; /* Parsing hashes */
			if(!strcasecmp(el, "resources")) data->state = 7; /* Parsing resources */
			break;
		/* Hashes */
		case 5:
			if(!strcasecmp(el, "pieces")) data->state = 6; /* Parsing chunk checksums */
			if(!strcasecmp(el, "hash")) {
				/* Check the type of the hash (must be specified) */
				for (i = 0; attr[i]; i += 2) {
					if(!strcasecmp(attr[i], "type")) {
						if(!strcasecmp(attr[i+1], "md5")) {
							data->hash_type = 1;
						} else if(!strcasecmp(attr[i+1], "sha1")) {
							data->hash_type = 2;
						} else {
							break; /* Not a valid hash type - skip this hash! */
						}
						data->read_text = 2; /* Reading a hash */
						break;
					}
				}
			}
			break;
		/* Chunk checksums */
		case 6:
			/* Not supported yet */
			break;
		/* Resources */
		case 7:
			if(!strcasecmp(el, "url")) {
				int has_type = 0;
				/* First check the protocol, so that it is supported (ie http or ftp). */
				for (i = 0; attr[i]; i += 2) {
					if(!strcasecmp(attr[i], "type")) {
						if(!strcasecmp(attr[i+1], "http") || !strcasecmp(attr[i+1], "ftp")) {
							data->read_text = 3; /* Reading an URL */
							data->check_protocol = 0;
							has_type = 1;
						}
						break;
					}
				}
				/* For compatibility with metalinks without a specified protocol */
				if(!has_type) {
					data->read_text = 3; /* We read the url and check it later (when the end tag is encountered) */
					data->check_protocol = 1; /* Examine the URL, later. */
				}
				/* If we are reading an URL, then add a mirror to this file */
				if(data->read_text == 3) {
					/* We save a pointer to the mirror, so that we can fill in the URL */
					data->mirror = metafile_add_mirror(data->file);
				}
			}
			break;
	}
}

void XMLCALL end(void *userData, const char *el) {
	parsedata *data = userData;
	if(data->state == 0) return;
	switch(data->state)
	{
		/* Ready */
		case 1:
			break;
		/* Metalink */
		case 3:
			if(!strcasecmp(el, "metalink")) data->state = 2; /* We are finished now! */
			break;
		/* File */
		case 4:
			if(!strcasecmp(el, "file")) data->state = 3; /* We are now parsing the metalink again */
			if(!strcasecmp(el, "size")) {
				/* Translate the file size into a number */
				data->file->size = strtod(data->file_size, 0);
				free(data->file_size);
				data->file_size = 0;
			}
			break;
		/* Hashes */
		case 5:
			if(!strcasecmp(el, "verification")) data->state = 4; /* Parsing file again */
			if(!strcasecmp(el, "hash")) {
				if(data->hash_type == 1) {
					if(strlen(data->file->hashes.md5) == 32) {
						data->file->hashes.has_md5 = 1;
					} else {
						data->file->hashes.has_md5 = 0;
						memset(data->file->hashes.md5, '\0', sizeof(data->file->hashes.md5));
					}
				} else if(data->hash_type == 2) {
					if(strlen(data->file->hashes.sha1) == 40) {
						data->file->hashes.has_sha1 = 1;
					} else {
						data->file->hashes.has_sha1 = 0;
						memset(data->file->hashes.sha1, '\0', sizeof(data->file->hashes.sha1));
					}
				}
			}
			break;
		/* Chunk checksums */
		case 6:
			if(!strcasecmp(el, "pieces")) data->state = 5; /* Parsing hashes again */
			break;
		/* Resources */
		case 7:
			if(!strcasecmp(el, "resources")) data->state = 4; /* Parsing file again */
			if(!strcasecmp(el, "url")) {
				/* Check the URL, so that it seems to be of a supported type (http or ftp) */
				data->mirror->url = trim(data->mirror->url);
				char *url = data->mirror->url;
				if(strncasecmp(url, "http://", 7) && strncasecmp(url, "ftp://", 6)) {
					/* Neither http or ftp. Remove the URL. */
					metalink_remove_mirror(data->file);
				}
				/* Check if this is a torrent file (.torrent), but only if the 'type' wasn't specified. */
				if(data->check_protocol) {
					if(ends_with(url, ".torrent")) {
						/* This is a torrent file. No support for Bittorrent, so remove it. */
						metalink_remove_mirror(data->file);
					}
				}
			}
			break;
	}
	data->read_text = 0; /* If we were reading something, we should stop doing that now */
	data->depth--;
}

void XMLCALL charhndl(void *userData, const XML_Char *s, int len)
{
	parsedata *data = userData;
	if(data->state == 0) return;
	char *buf = (char*)calloc(len + 1, sizeof(char));
	strncpy(buf, s, len);
	
	switch(data->read_text)
	{
		/* Identity */
		case 1:
			addstring(&data->ml->identity, buf);
			break;
		/* Hash */
		case 2:
			if(data->hash_type == 1) {
				strncat(data->file->hashes.md5, buf, 32);
			} else if(data->hash_type == 2) {
				strncat(data->file->hashes.sha1, buf, 40);
			}
			break;
		/* URL */
		case 3:
			addstring(&data->mirror->url, buf);
			break;
		/* File size */
		case 4:
			addstring(&data->file_size, buf);
			break;
	}
	
	free(buf);
}

void init_parsedata(parsedata *data)
{
	memset(data, '\0', sizeof(parsedata));
	data->state = 1;
}

metalink* metalink_parse_file(char *filename)
{
	FILE *f;
    size_t n;
	parsedata data;
	char buf[1024];
	
	init_parsedata(&data);
	data.ml = create_metalink();
	data.parser = XML_ParserCreate(0);
	if(!data.parser) return 0;
	XML_SetElementHandler(data.parser, start, end);
	XML_SetCharacterDataHandler(data.parser, charhndl);
	XML_SetUserData(data.parser, &data);
	
	f = fopen(filename, "rb");
    if(f == 0) {
		XML_ParserFree(data.parser);
		metalink_free(data.ml);
		return 0;
	}
	while(1)
	{
		n = fread(buf, 1, sizeof(buf), f);
		if(n <= 0) break;
		if(XML_Parse(data.parser, buf, n, 0) == XML_STATUS_ERROR) {
			XML_ParserFree(data.parser);
			metalink_free(data.ml);
			fclose(f);
			return 0;
		}
	}
	XML_Parse(data.parser, buf, 0, 1);
	fclose(f);
	XML_ParserFree(data.parser);
	/* Don't return anything if an error occured! */
	if(data.state != 2) {
		metalink_free(data.ml);
		return 0;
	}
	return data.ml;
}

metalink* create_metalink()
{
	return (metalink*)calloc(1, sizeof(metalink));
}

void metalink_add_file(metalink *ml, metafile *file)
{
	if(ml->num_files == 0) {
		ml->first_file = file;
		ml->last_file = file;
	} else {
		ml->last_file->next = file;
		ml->last_file = file;
	}
	ml->num_files++;
}

void metalink_remove_file(metalink *ml)
{
	if(ml->num_files > 0) {
		metafile *file = ml->first_file;
		ml->first_file = file->next;
		if(file->filename) free(file->filename);
		metafile_free_mirrors(file);
		free(file);
		ml->num_files--;
		if(ml->num_files == 0) ml->last_file = 0;
	}
}

void metalink_free(metalink *ml)
{
	if(ml == 0) return;
	if(ml->identity) free(ml->identity);
	while(ml->num_files > 0) {
		metalink_remove_file(ml);
	}
	free(ml);
}

metafile* create_metafile()
{
	metafile *file = calloc(1, sizeof(metafile));
	file->size = -1; /* Indicates that the file size is unknown so far */
	return file;
}

metamirror* metafile_add_mirror(metafile *file)
{
	metamirror *mirror = calloc(1, sizeof(metamirror));
	addstring(&mirror->url, ""); /* Add an empty string, so that we can be sure to have a string stored in URL */
	/* Add the mirror first in the list */
	if(file->first_mirror) {
		mirror->next = file->first_mirror;
		file->first_mirror = mirror;
	} else {
		file->first_mirror = mirror;
		file->last_mirror = mirror;
	}
	file->num_mirrors++;
	return mirror;
}

void metalink_remove_mirror(metafile *file)
{
	/* Remove the first mirror (the last one added) */
	if(file->first_mirror) {
		metamirror *mirror = file->first_mirror;
		file->first_mirror = mirror->next;
		free(mirror->url);
		free(mirror);
		file->num_mirrors--;
		if(file->num_mirrors == 0) file->last_mirror = 0;
	}
}

void metafile_free_mirrors(metafile *file)
{
	while(file->num_mirrors > 0) {
		metalink_remove_mirror(file);
	}
}
