#include <stdio.h>
#include <stdlib.h>
#include "../metalink.h"

int main()
{
	metalink *ml = metalink_parse_file("test.metalink");
	if(!ml) {
		printf("metalink_parse_file returned an error!\n");
	} else {
		printf("Metalink: identity=\"%s\" num_files=%d\n", ml->identity, ml->num_files);
		if(ml->num_files > 0) {
			printf("Files:\n");
			metafile *file = ml->first_file;
			while(file) {
				printf("%s (%d)\n", file->filename, (int)file->size);
				metamirror *mirror = file->first_mirror;
				while(mirror) {
					printf("  %s\n", mirror->url);
					mirror = mirror->next;
				}
				file = file->next;
			}
		}
		metalink_free(ml);
	}
	return EXIT_SUCCESS;
}
