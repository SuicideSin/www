MetaDL 0.1 - metalink downloading plugin for NSIS
Copyright (c) 2007 Hampus Wessman (hw@vox.nu)
-------------------------------------------------

USAGE
-----

MetaDL:download [options] url local-file

The return value is pushed to the stack:

  "cancel" if cancelled
  "success" if success
  otherwise, an error string describing the error

If you don't want the progress window to appear, use NSISdl::download_quiet.

OPTIONS
-------

/PROXY proxy.whatever.com
/PROXY proxy.whatever.com:8080

/RETRYTIME=5 (this changes the time between retries; default=5)
/MAXTRIES=0  (max tries; 0=infinite, 1=no retries, ...; default=0)
/HASHTRIES=0 (max tries when checksums fail, works as max tries; default=0)

/MD5 the-hash  (use this hash to validate the download; no md5 as default)
/SHA1 the-hash (use this hash to validate the download; no sha1 as default)
both md5 and sha1 can be used at the same time!

/MIRRORS=2 url1 url2 (add these mirrors. You still need an "ordinary" url, so leave one mirror for that!)

An example from my test (only the main url worked, but it was nice for testing):
MetaDL::download /RETRYTIME=5 /MAXTRIES=0 /HASHTRIES=0 /MD5 4d28c6dcf75f56684c57f4111eef608d /SHA1 ed825b91749cd89bf7afb8e81c390e14c262d2fe /MIRRORS=2 http://localhost:8081/download1/test.avi http://localhost:8081/download2/test.avi http://localhost:8081/download/test.avi $INSTDIR\test.avi

It is also possible to translate the plugin (not compatible with NSISdl though!) and set all the other options from NSISdl (which aren't used right now).

HOW IT BEHAVES
--------------

The plugin first looks for the local-file. If it exists it checks the hashes and if none fails it is done! Otherwise the old file is deleted (if there was one) and it looks for a file names local-file.partial. If there is one it continues at the end of the file, otherwise it creates one. Then the downloading begins. Mirrors are selected at random to begin with, but errors and in which order they was last tested is remember. After a while it picks the "best" server to try. I won't get into details about this, but it works quite well.
If errors occur then it updates the info about the mirrors (in memory) and checks if any more retries should be done (depends on 'max tries'). This the total number of tries (not per mirror). When the file is downloaded the checksums are checked. If the file doesn't validate it is deleted and the process starts over again (depending on 'hash tries'). If the file is correct, then it is renamed to 'local-file'.

If not "cancel" or "success" is returned, an error message will always be returned instead, that explains what went wrong!