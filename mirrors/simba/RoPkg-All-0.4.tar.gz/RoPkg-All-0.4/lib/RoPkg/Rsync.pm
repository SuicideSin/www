package RoPkg::Rsync;

use strict;
use warnings;

use vars qw($VERSION);

$VERSION='0.2+alpha5';

1;
