############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License as published by    #
## the Free Software Foundation; version 2 of the License.                 #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::Plugin::Fedora;

use warnings;
use strict;

use vars qw($VERSION $tmpl);
$VERSION='0.1.1';

use Data::Dumper;
use HTML::Template;

use RoPkg::Metalink::File;

use RoPkg::Exceptions;
use English      qw( -no_match_vars );
use Scalar::Util qw(blessed);

use RoPkg::Metalink::PBase;
use base qw(RoPkg::Metalink::PBase);

sub new {
  my ($class, %opt) = @_;
  my $self;

  $self = $class->SUPER::new(%opt);
  $self->{pname} = 'fedora';

  return $self;
}

sub Harvest {
  my ($self, $entry, @locations) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Plugin::Fedora',
    );
  }

  if ((scalar @locations) == 0) {
    push @locations, qw(
                       /core/2/i386/iso/
                       /core/2/x86_64/iso/
                       /core/3/i386/iso/
                       /core/3/x86_64/iso/
                       /core/4/i386/iso/
                       /core/4/x86_64/iso/
                       /core/4/ppc/iso/
                       /core/5/i386/iso/
                       /core/5/x86_64/iso/
                       /core/5/ppc/iso/
                       /core/test/5.90/i386/iso/
                       /core/test/5.90/ppc/iso/
                       /core/test/5.90/x86_64/iso/
                       );
  }

  $self->_harvest(
    $entry,
    sub {
      (
       $_[0] =~ m{^ FC - \d+ - (i386|x86_64|ppc) - .* \.iso $}xm ||
       $_[0] =~ m{^ FC \d+ - (i386|x86_64|ppc) - .* \.iso $}xm ||
       $_[0] =~ m{^ FC - \d+ - (Test\d+) - .* \.iso $}xm
      ) && $_[0] !~ m{.* rescuecd .*}xm
    },
    1,
    @locations,
  );
 
  return 1;
}

sub Generate {
  my ($self, $entry, $mirrors) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Plugin::Fedora',
    );
  }
 
  return $self->_generate($entry, $mirrors);
}

sub _get_version {
  my ($self, $filename) = @_;

  if ( $filename =~ m{^ FC(\d+) - (i386|x86_64|ppc).*}xm ) {
    return $1;
  }

  if ( $filename =~ m{^ FC - (\d+) - (Test\d+) - .* \.iso $}xm ) {
     return $1 . $2;
  }


  $filename =~ m{^ FC - (\d+) - (i386|x86_64|ppc) .*}xm;
  return $1;
}

sub _get_arch {
  my ($self, $filename) = @_;

  $filename =~ m{^FC .* - (i386|x86_64|ppc) .*}xm;
  return ($1);
}

sub _get_os {
  my ($self, $filename) = @_;

  return $self->_get_arch($filename);
}

1;
