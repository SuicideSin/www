############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License as published by    #
## the Free Software Foundation; version 2 of the License.                 #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::Plugin::OpenOffice;

use warnings;
use strict;

use vars qw($VERSION $tmpl);
$VERSION='0.1';

use Data::Dumper;
use HTML::Template;

use RoPkg::Metalink::File;

use RoPkg::Exceptions;
use English      qw( -no_match_vars );
use Scalar::Util qw(blessed);

use RoPkg::Metalink::PBase;
use base qw(RoPkg::Metalink::PBase);

sub new {
  my ($class, %opt) = @_;
  my $self;

  $self = $class->SUPER::new(%opt);
  $self->{pname} = 'openoffice';

  return $self;
}

sub Harvest {
  my ($self, $entry, @locations) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Plugin::OpenOffice',
    );
  }
  
  $self->_harvest(
    $entry,
    sub {
      $_[0] =~ m{^ OOo_ .* install .* (tar\.gz|exe) $}xm
    },
    1,
    qw(
      /stable/
    ),
  );
 
  return 1;
}

sub Generate {
  my ($self, $entry, $mirrors) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Plugin::OpenOffice',
    );
  }

  return $self->_generate($entry, $mirrors);
}

sub _cb_mtgen_after_file_mirrors {
  my ($self, $lfd, $file) = @_;

  $lfd->{TorrentBase} = 'http://borft.student.utwente.nl/openoffice/torrents/';
  return $lfd->{TorrentBase};
}

sub _get_version {
  my ($self, $filename) = @_;

  $filename =~ m{OOo_ (\d+ \. \d+ \. \d+ \.* \d*) .* _install_ .*}xm;
  return $1;
}

sub _get_arch {
  my ($self, $filename) = @_;

  $filename =~ m{OOo_ (\d*\.*)* _ (Linux|Solaris|Win32) (Intel|Sparc|x86)_ .*}xm;
  return ($2, $3);
}

sub _get_os {
  my ($self, $filename) = @_;
  my $os;

  my ($platform, $arch) = $self->_get_arch($filename);

  if ($arch =~ m{^Intel$}xm ) {
    $arch = 'x86';
  }

  if ($platform =~ m{^Win32$}xm) {
    $platform = 'Windows';
  }

  if ($arch =~ m{Sparc}xm) {
    $arch = 'SPARC';
  }

  return ($platform . q{-} . $arch);
}

1;
