############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License as published by    #
## the Free Software Foundation; version 2 of the License.                 #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::Mirrors;

use strict;
use warnings;

use Scalar::Util qw(blessed);

use RoPkg::Exceptions;
use RoPkg::DBCollection;

use vars qw($VERSION);

$VERSION='0.1.1';
use base qw(RoPkg::DBCollection);

sub new {
  my ($class, %opt) = @_;
  my $self;

  $self = $class->SUPER::new(%opt);
  $self->{table} = 'Mirrors';

  return $self;
}

sub Count {
  my ($self, $fields) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Mirrors',
    );
  }

  return $self->_count($fields);
}

sub Get {
  my ($self, $fields) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Mirrors'
    );
  }

  return $self->_get('RoPkg::Metalink::Mirror',$fields);
}

1;

__END__

=head1 NAME

RoPkg::Metalink::Mirrors

=head1 VERSION

0.1.1

=head1 SYNOPSIS

 use RoPkg::Metalink::Mirrors;
 use English qw(-no_match_vars);

 sub main {
   my $mirrors = new RoPkg::Metalink::Mirrors(
                   dbo        => $db_object,
                   dbo_method => 'db_metalink',
                 );

   print 'Number of mirrors is:', $mirrors->Count(), $RS;

   return 0;
 }

=head1 DESCRIPTION

This class is used to retrive mirrors from the metalink generator database. 
It inherits RoPkg::DBCollection class.

=head1 SUBROUTINES/METHODS

The following subroutines are available:

=head2 new()

The class constructor. At this moment the constructor has 2 parameters (both
of them are required). For more information about the parameters of this
method please refer to the RoPkg::DBCollection man page

=head2 Count($fields)

Returns the number of records found in database, according to $fields specifications.
The $fields variable must be specified in SQL::Abstract format. For more information
related to this please refer to the SQL::Abstract man page.

=head2 Get($fields)

Returns an array of RoPkg::Metalink::Mirror objects, initialized with the values
from the database. The database records are filtered according to $fields. $fields must 
be specified in SQL::Abstract format.

=head1 SEE ALSO

L<RoPkg::Metalink> L<RoPkg::Mirror>

=head1 PERL CRITIC

This code is perl critic level 2 compliant

=head1 DIAGNOSTICS

This module has his own tests in the t directory. To run the tests, unpack
the source and use 'make test' command.

=head1 CONFIGURATION AND ENVIRONMENT

This class does not use a configuration file. No environment variables are used.

=head1 DEPENDENCIES

This class, requires:

=over 2

=item RoPkg (>= 0.5.6)

=item Scalar::Util

=back

=head1 INCOMPATIBILITIES

None known to the author

=head1 BUGS AND LIMITATIONS

No bugs known to the author. If you find a bug, or if you want to
find the updated list of bugs please refer to the http://bugs.packages.ro
website.

=head1 AUTHOR

Subredu Manuel <diablo@iasi.roedu.net>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2005 Subredu Manuel.  All Rights Reserved.
This module is free software; you can redistribute it 
and/or modify it under the same terms as Perl itself.
The LICENSE file contains the full text of the license.

=cut
