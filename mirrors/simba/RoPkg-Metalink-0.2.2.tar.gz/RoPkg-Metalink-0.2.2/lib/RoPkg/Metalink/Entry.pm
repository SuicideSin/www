############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License as published by    #
## the Free Software Foundation; version 2 of the License.                 #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::Entry;

use strict;
use warnings;

use RoPkg::DBObject;
use Scalar::Util qw(blessed);

use vars qw($VERSION);
$VERSION='0.1.2';

use base qw(RoPkg::DBObject);

my $pf = {
  id           => q{-},
  Name         => q{-},
  Description  => q{-},
  Tags         => q{-},
  License      => q{-},
  LocalDir     => q{-},
  WebSite      => q{-},
  Enabled      => q{-},
  InProgress   => q{-},
};

sub new {
  my ($class, %opt) = @_;
  my $self;

  $opt{pf} = $pf;
  $self    = $class->SUPER::new(%opt);
  $self->{_sql_table} = 'Entries';

  return $self;
}

sub Add {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
     error    => 'Called outside class instance',
     pkg_name => 'RoPkg::Metalink::Entry',
    );
  }

  $self->chkp(qw(Name License Plugin LocalDir WebSite));

  return $self->SQL_Insert();
}

sub Delete {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Entry',
    );
  }

  $self->chkp(qw(id));
  return $self->SQL_Delete(qw(id));
}

sub Update {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Entry',
    );
  }

  $self->chkp(qw(id));

  return $self->SQL_Update(qw(id));
}

sub Load {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Entry',
    );
  }

  if (defined($self->{Name})) {
    return $self->SQL_Select(qw(Name));
  }

  if (defined($self->{id})) {
    return $self->SQL_Select(qw(id));
  }

  Param::Missing->throw(
    error    => 'Nor id not Name has been specified',
    pkg_name => 'RoPkg::Metalink::Entry',
  );

  #Syntactic sugar ;)
  return 1;
}

1;

__END__

=head1 NAME

RoPkg::Metalink::Entry

=head1 VERSION

0.1.2

=head1 SYNOPSIS

 use RoPkg::Metalink::Entry;

 $entry = new RoPkg::Metalink::Entry(
            dbo        => $db,
            dbo_method => 'metalink',
          );

 $entry->Name('test');
 $entry->Add();

=head1 DESCRIPTION

This class is a mapper for Entries table from metalink generator database.

=head1 SUBROUTINES/METHODS

The following subroutines are available:

=head2 new()

The class constructor. At this moment the constructor has 2 parameters (both
of them are required). For more information about the parameters of this
method please refer to the RoPkg::DBCollection man page

=head2 Add()

Add the current object to the database.

=head2 Delete()

Delete the current object from the database.

=head2 Update()

Synchronize the content of this object with the database.

=head2 Load()

Loads the object from the database. At least Name or id must
pe specified before calling this method, or else, a Param::Missing
exception will be raised.

=head2 id()

The id (internal) for this entry. When you add new records to the
database, please set id to 0.

=head2 Name()

Get/Set method . With this method you can access the name of the entry.

=head2 Description()

Get/Set method. With this method you can access the description of the entry.

=head2 Tags()

Get/Set method. With this method you can access the tags of the entry.

=head2 License()

Get/Set method. With this method you can access the license of the entry.

=head2 LocalDir()

Get/Set method. With this method you can access the local directory for the entry.

=head2 WebSite()

Get/Set method. With this method you can access the website for the entry.

=head2 Enabled()

Get/Set method. With this method you can enable/disable the entry. You can use
2 values: 0 (disabled), 1 (enaled)

=head2 InProgress()

Get/Set method. With this method you can specify that the entry is in progress.
You can use 2 values: 0 (not in progress), 1 (in progress)

=head1 SEE ALSO

L<RoPkg::Metalink> L<RoPkg::Metalink::Entries>

=head1 PERL CRITIC

This code is perl critic level 2 compliant

=head1 DIAGNOSTICS

This module has his own tests in the t directory. To run the tests, unpack
the source and use 'make test' command.

=head1 CONFIGURATION AND ENVIRONMENT

This class does not use a configuration file. No environment variables are used.

=head1 DEPENDENCIES

This class, requires:

=over 2

=item RoPkg (>= 0.5.6)

=item Scalar::Util

=back

=head1 INCOMPATIBILITIES

None known to the author

=head1 BUGS AND LIMITATIONS

No bugs known to the author. If you find a bug, or if you want to
find the updated list of bugs please refer to the http://bugs.packages.ro
website.

=head1 AUTHOR

Subredu Manuel <diablo@iasi.roedu.net>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2005 Subredu Manuel.  All Rights Reserved.
This module is free software; you can redistribute it 
and/or modify it under the same terms as Perl itself.
The LICENSE file contains the full text of the license.

=cut
