############################################################################
##           Copyright (C) 2006 Subredu Manuel                             #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License v2 as published by #
## the Free Software Foundation                                            #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::File;

use strict;
use warnings;

use RoPkg::DBObject;

use Scalar::Util qw(blessed);

use vars qw($VERSION);
use base qw(RoPkg::DBObject);

$VERSION='0.1.1';

my $pf = {
  id               => q{-},
  EntryID          => q{-},
  Filename         => q{-},
  Size             => q{-},
  HashType         => q{-},
  HashValue        => q{-},
  Path             => q{-},
  LastUpdate       => q{-},
  sha1             => q{-},
  tth              => q{-},
  ed2k             => q{-},
  kzhash           => q{-},
};

sub new {
  my ($class, %opt) = @_;
  my $self;

  $opt{pf} = $pf;
  $self    = $class->SUPER::new(%opt);
  $self->{_sql_table} = 'Files';

  return $self;
}

sub Add {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
     error    => 'Called outside class instance',
     pkg_name => 'RoPkg::Metalink::File',
    );
  }

  $self->chkp(qw(EntryID Filename Path Size HashType HashValue LastUpdate));

  return $self->SQL_Insert();
}

sub Delete {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::File',
    );
  }

  $self->chkp(qw(id));
  return $self->SQL_Delete(qw(id));
}

sub Update {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::File',
    );
  }

  $self->chkp(qw(id));

  return $self->SQL_Update(qw(id));
}

sub Load {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::File',
    );
  }

  $self->chkp(qw(id));
  return $self->SQL_Select(qw(id));
}

1;


__END__

=head1 NAME

RoPkg::Metalink::File

=head1 VERSION

0.1.1

=head1 SYNOPSIS

 use RoPkg::Metalink::File;

 my $file = new RoPkg::Metalink::File(
              dbo        => $db,
              dbo_method => 'metalink'
            );

 $file->Filename('FC-5-dvd.iso');
 $file->Size(4098123123);
 $file->sha1(..);

 $file->Add();

=head1 DESCRIPTION

This class is a database object mapper for Files table. 

=head1 SUBROUTINES/METHODS

The following subroutines are available:

=head2 new()

The class constructor. At this moment the constructor has 2 parameters (both
of them are required). For more information about the parameters of this
method please refer to the RoPkg::DBCollection man page

=head2 Get/Set methods

The following methods are Get/Set methods.

=over 12

=item *) id - the internal object id

=item *) EntryID - the ID of the entry who is related to this file object

=item *) Filename - the file name

=item *) Size - the size of the file

=item *) HashType - the type of hash used to check the file (for now only MD5 is supported)

=item *) HashValue - the value of the hash

=item *) Path - the path to the file

=item *) LastUpdate - the timestamp of the last update of the file

=item *) sha1 - the sha1 hash

=item *) tth - the magnet hash

=item *) ed2k - the edonkey hash

=item *) kzhash - the kazaa hash

=back

Besides these methods, there are another four methods used to deal with database.

=head2 Add()

This method, add the current object to the database. The id parameter must be set to 0
before calling the Add() method.

=head2 Delete()

Deletes the object from the database. The id parameter must be set and must be not 0

=head2 Update()

Updates the database with the values from the object. id must be defined and not 0

=head2 Load()

Load the object from the database. Before calling this method, the id parameter
must be defined and not 0

=head1 SEE ALSO

L<RoPkg::Metalink> L<RoPkg::Metalink::Files>

=head1 PERL CRITIC

This code is perl critic level 2 compliant

=head1 DIAGNOSTICS

This module has his own tests in the t directory. To run the tests, unpack
the source and use 'make test' command.

=head1 CONFIGURATION AND ENVIRONMENT

This class use does not use a configuration file. No environment variables are used.

=head1 DEPENDENCIES

This class, requires:

=over 2

=item RoPkg (>= 0.5.6)

=item Scalar::Util

=back

=head1 INCOMPATIBILITIES

None known to the author

=head1 BUGS AND LIMITATIONS

No bugs known to the author. If you find a bug, or if you want to
find the updated list of bugs please refer to the http://bugs.packages.ro
website.

=head1 AUTHOR

Subredu Manuel <diablo@iasi.roedu.net>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2005 Subredu Manuel.  All Rights Reserved.
This module is free software; you can redistribute it 
and/or modify it under the same terms as Perl itself.
The LICENSE file contains the full text of the license.

=cut
