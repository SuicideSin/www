############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License as published by    #
## the Free Software Foundation; version 2 of the License.                 #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::PBase;

use warnings;
use strict;

use vars qw($VERSION $tmpl);
$VERSION='0.2.1';

use HTML::Template;
use RoPkg::Metalink::File;
use Data::Dumper;
use RoPkg::Exceptions;
use RoPkg::Utils qw(CreateFile ZeroPad CleanURI CheckParam CleanPath GetMD5 ReadFile);
use English      qw( -no_match_vars );
use Scalar::Util qw(blessed);

sub new {
  my ($class, %opt) = @_;
  my $self;

  $self = bless { %opt }, $class;

  CheckParam($self, qw(files_obj config));
  $self->{pname} = '_the_plugin_name_must_be_set_';

  return $self;
}

# Returns the list of files from the database.
# If no files are found, a empty array is returned.
sub _get_db_files {
  my ($self, $entry) = @_;
  my @files;

  eval {
    @files = $self->{files_obj}->Get({EntryID => $entry->id});
  };

  if ( Exception::Class->caught('DB::NoResults') ) {
    return ();
  }
  else {
    if (ref($EVAL_ERROR)) {
      $EVAL_ERROR->rethrow;
    }
  }

  return @files;
}

# Check if the files exists on the filesystem.
# If not, remove them from the database.
# Modified files are also removed from the database.
#   Returns the list of valid files (File objects)
sub _check_db_files {
  my ($self, $entry, @files) = @_;
  my @efiles;

  foreach(@files) {
    my $file = $_;
    my $fpath;

    $fpath = sprintf('%s/%s/%s',
               $entry->LocalDir,
               $file->Path,
               $file->Filename
             );
    
    $fpath = CleanPath($fpath);
    
    if ( ! -f $fpath ) {
      print 'Removing ',$fpath,' from database',$RS;
      $file->Delete();
      next;
    }
    else { 
      my $mtime = $self->_get_file_mtime($fpath);

      if ($mtime != $file->LastUpdate) {
        print 'File ',$fpath,' has been modified. Removing from database',$RS;
        $file->Delete();
        next;
      }
    }

    push @efiles, $fpath;
  }

  return @efiles;
}

#This method returns the file list found in the
#directories specified in @subdir array.
sub _get_fs_files {
  my ($self, $entry, $filter_method, $recursive, @subdir) = @_;
  my (@flist, $dname, $dh);

  if ((scalar @subdir) == 0) {
    push @subdir, q{./};
  }

  foreach(@subdir) {
    my $sdname = $_;

    $dname = CleanPath($entry->LocalDir . q{/} . $sdname);
    if ( !opendir($dh, $dname) ) {
      Dir::Open->throw(
        error    => 'Could not open ' . $dname,
        pkg_name => ref($self),
        dirname  => $dname,
      );
    }

    while(my $filename = readdir($dh)) {
      next if ($filename eq q{.} || $filename eq q{..});
      
      if ( -f "$dname/$filename" ) {
        
        #Here one must specify the regexp to be compared with the file name
        next if ( ! &$filter_method($filename) );
        push @flist, CleanPath("$dname/$filename");
      }
      if ( -d "$dname/$filename" ) {
        if ( $recursive ) {
          push @flist, $self->_get_fs_files($entry, $filter_method, 1, "$sdname/$filename");
        }
      }
    }
    closedir($dh);
  }

  return @flist;
}

sub _harvest {
  my ($self, $entry, $filter_method, $recursive, @locations) = @_;
  my (@db_files, @fs_files);

  if ( $entry->Name ne $self->{pname} ) {
    return 0;
  }

  #No locations specified ? Load the default one
  if ((scalar @locations) == 0) {
    push @locations, $entry->LocalDir;
  }

  #Get the list of files from the database
  @db_files = $self->_get_db_files($entry);
  
  #Verify the files (the ones who doesn't exists anymore, remove them)
  @db_files = $self->_check_db_files($entry, @db_files);
  
  #Get the list of local files
  @fs_files = $self->_get_fs_files($entry, $filter_method, $recursive, @locations);

  foreach(@fs_files) {
    my $fs_file = $_;

    #ignore the file if is already in database
    next if (RoPkg::Utils::ElemInList($fs_file, @db_files));
    
    #new file ! add him to database
    $self->_add_file_to_db($entry, $fs_file);
  }

  return 1;
}

# Add a file to the database
sub _add_file_to_db {
  my ($self, $entry, $fs_file) = @_;
  my $file;

  print 'Adding ',$fs_file,$RS;

  $file = new RoPkg::Metalink::File(
            dbo        => $self->{files_obj}->dbo(),
            dbo_method => $self->{files_obj}->dbo_method()
          );

  $file->id(0);
  $file->EntryID($entry->id);
  $file->Filename($self->_get_filename($fs_file));
  $file->Size($self->_get_file_size($fs_file));
  $file->LastUpdate($self->_get_file_mtime($fs_file));
  $file->Path(CleanPath($self->_get_file_path($entry, $fs_file)));
  $file->HashType('MD5');

  if ($file->Size > 2_000_000_000 ) {
    #bitcollider doesn't work with files greater than 2G
    $file->HashValue(GetMD5($fs_file));
  }
  else {
    #If something went wrong with magnet links
    if ( $self->_add_magnet_info($file, $entry, $fs_file) != 1 ) {
      #we have to generate the md5 cause otherwise, we can't generate the metalink file
      $file->HashValue(GetMD5($fs_file));
    }
  }
  
  $file->Add();
  return 1;
}

sub _add_magnet_info {
  my ($self, $file, $entry, $fs_file) = @_;
  my $tmp_file;
  my $bt;

  return 0 if (! exists($self->{config}->{common}->{bitcollider}));
  $bt = $self->{config}->{common}->{bitcollider};
  if ( ! -f $bt || ! -x $bt ) {
    print 'bitcollider not found or is not executable (',$bt,q{)},$RS;
    return 0;
  }

  $tmp_file = '/tmp/mt-bitcolider.tmp';
  print 'Running bitcolider',$RS;
  system("$bt --md5 -p $fs_file > $tmp_file 2> /dev/null");
  $self->_parse_bitcolider_output($file, $tmp_file);
  unlink $tmp_file;

  return 1;
}

sub _parse_bitcolider_output {
  my ($self, $file, $filename) = @_;
  my $content;

  $content = ReadFile($filename);

  if ($content =~ m{ bitprint = (\w+) \. (\w+) }xm) {
    $file->sha1($1);
    $file->tth($2);
  }

  if ($content =~ m{ tag \. ed2k \. ed2khash \= (\w+) }xm) {
    $file->ed2k($1);
  }

  if ($content =~ m{ tag \. kzhash \. kzhash \= (\w+) }xm) {
    $file->kzhash($1);
  }

  if ($content =~ m{ tag \. md5 \. md5 \= (\w+) }xm) {
    $file->HashValue($1);
  }

  return 1;
}

sub _get_file_path {
  my ($self, $entry, $fs_file) = @_;
  my ($fname);

  $fs_file = substr(
                $fs_file,
                length($entry->LocalDir),
                (length($fs_file) - length($entry->LocalDir))
            );
  $fs_file = substr(
               $fs_file,
               0,
               length($fs_file) - length($self->_get_filename($fs_file))
             );

  return q{/} . $fs_file;
}

sub _make_checks {
  my ($self, $entry) = @_;

  if ($entry->Name ne $self->{pname}) {
    return 0;
  }

  if ( !exists($self->{config}->{plugins}->{ $self->{pname} }) ||
       (exists($self->{config}->{plugins}->{ $self->{pname} }->{enabled}) &&
        $self->{config}->{plugins}->{ $self->{pname} }->{enabled} == 0)
     ) {
    return 0;
  }
  
  return 1;
}

sub _generate {
  my ($self, $entry, $mirrors, $custom_resources) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => ref($self),
    );
  }

  if ( ! $self->_make_checks($entry) ) {
    return 0;
  }

  $self->_init_template();
  $self->_init_general_info($entry);

  my @db_files;
  
  eval {
    @db_files = $self->{files_obj}->Get({EntryID => $entry->id});
  };
  
  if (Exception::Class->caught('DB::NoResults')) {
    print 'No files for ',$entry->Name,$RS;
    return 0;
  }
  else {
    if (ref($EVAL_ERROR)) {
      $EVAL_ERROR->rethrow();
    }
  }

  foreach(@db_files) {
    my $file = $_;

    $self->_generate_metalink($file, $entry, $mirrors, $custom_resources);
  }

  return 1;
}

sub _generate_metalink {
  my ($self, $file, $entry, $mirrors, $custom_resources) = @_;
  my (%lfd, $ddir, $mtfile, @loop_data);

  $ddir = $self->_get_output_dir();
  if ( ! -d $ddir ) {
    if ( ! mkdir($ddir) ) {
      Dir::Create->throw(
        error    => "Could not create directory $ddir",
        pkg_name => ref($self),
        dirname  => $ddir,
      );
    }
  }
  
  $mtfile = $ddir . $file->Filename;
  $mtfile =~ s{\.}{_}xmg;
  $mtfile .= q{.} . $self->{config}->{common}->{file_ext};

  #Check if metalink file already exists
  if ( -f $mtfile ) {
    #The metalink file exists. Let's see if we overwrite it or not
    if ( !$self->{config}->{common}->{overwrite} ) {
      #If overwrite is not specified assume NO
      return;
    }
    
    #If overwrite exists and is 0 don't overwrite
    if ($self->{config}->{overwrite} && $self->{config}->{overwrite} == 0) {
      return;
    }
  }

  $tmpl->param(FileDownloadURL => CleanURI(
                 $self->{config}->{common}->{download_url} . q{/} .
                 $self->{config}->{plugins}->{ $self->{pname} }->{url_dir} . q{/} .
                 $file->Filename . q{.} . $self->{config}->{common}->{file_ext}));
  
  print 'Generating ',$mtfile,$RS;

  $lfd{FileName} = $file->Filename;
  $lfd{FileMD5}  = $file->HashValue;
  $lfd{FileSize} = $file->Size;
  $lfd{sha1}     = $file->sha1();
  $lfd{tth}      = $file->tth();
  $lfd{ed2k}     = $file->ed2k();
  $lfd{kzhash}   = $file->kzhash();
  $lfd{OS}       = $self->_get_os($file->Filename);
  %lfd = %{ $self->_add_file_mirrors($file, \%lfd, $entry, $mirrors) };

  if ($custom_resources) {
    $lfd{CustomResources} = $custom_resources;
  }

  if($self->can('_cb_mtgen_after_file_mirrors')) {
    $self->_cb_mtgen_after_file_mirrors(\%lfd, $file);
  }

  $tmpl->param(Name    => $lfd{FileName});
  $tmpl->param(Version => $self->_get_version($file->Filename));

  push @loop_data, \%lfd;
  $tmpl->param(FilesList => \@loop_data);
  CreateFile($mtfile, $tmpl->output);

  return 1;
}

sub _get_file_size {
  my ($self, $filename) = @_;
  my @fstat;

  @fstat = stat($filename);
  return $fstat[7];
}

sub _get_file_mtime {
  my ($self, $filename) = @_;
  my @fstat;

  @fstat = stat($filename);
  return $fstat[9];
}

sub _get_filename {
  my ($self, $filename) = @_;
  
  $filename =~ m{^ .*\/ (.*) $}xm;
  return $1;
}

sub _get_version {
  my ($self, $filename) = @_;

  $filename =~ m{linux- (\d+ \. \d+ \. \d+ \.* \d*) \. tar\.(gz|bz2)$}xm;
  return $1;
}
  
  
sub _add_file_mirrors {
  my ($self, $file, $lfd, $entry, $mirrors) = @_;
  my @loop_data;

  foreach(@{ $mirrors }) {
    my $mirror = $_;
    my %md;
    my $url;

    $md{MirrorProtocol}   = $mirror->Protocol;
    $md{MirrorCountry}    = $mirror->CountryShort;
    $md{MirrorPreference} = $mirror->Priority;

    $url = sprintf('%s://%s/%s/%s',
             $mirror->Protocol,
             $mirror->BaseURL,
             $file->Path,
             $file->Filename
           );
    $md{FileURL} = CleanURI($url);

    push @loop_data, \%md;
  }

  $lfd->{URL_LIST} = \@loop_data;

  return $lfd;
}

sub _init_general_info {
  my ($self, $entry) = @_;

  $tmpl->param(Name            => $entry->Name);
  $tmpl->param(PublicationDate => $self->_get_current_date());
  $tmpl->param(RefreshDate     => $self->_get_current_date());
  $tmpl->param(Website         => $entry->WebSite);
  $tmpl->param(License         => $entry->License);
  $tmpl->param(LicenseURL      => $self->_get_license_url($entry->License));
  $tmpl->param(Description     => $entry->Description);
  $tmpl->param(Tags            => $entry->Tags);
  $tmpl->param(PublisherName   => $self->{config}->{common}->{publisher_name});
  $tmpl->param(PublisherURL    => $self->{config}->{common}->{publisher_url});

  return 1;
}

sub _get_current_date {
  my ($self) = @_;
  my ($res, @items);

  @items = localtime(time());

  return sprintf('%s-%s-%s-%s:%s:%s',
           ($items[5] + 1900),
           ZeroPad($items[4]+1, 2),
           ZeroPad($items[3], 2),
           ZeroPad($items[2], 2),
           ZeroPad($items[1], 2),
           ZeroPad($items[0], 2)
         );
}

sub _get_license_url {
  my ($self, $license) = @_;

  if ($license =~ m{gpl}xmi) {
    return 'http://www.gnu.org/copyleft/gpl.html';
  }
  else {
    return 'unknown';
  }
}

sub _init_template {
  my ($self) = @_;

  $tmpl = new HTML::Template(
            filename          => $self->{config}->{common}->{template},
            loop_context_vars => 1,
            die_on_bad_params => 0,
          );

  return 1;
}

sub _check_files_and_dirs {
  my ($self, $config, $entry) = @_;

  if ( ! -f $config->{common}->{template} ) {
    File::NotFound->throw(
      error    => 'Template file not found',
      pkg_name => ref($self),
    );
  }

  return 1;
}

sub _get_output_dir {
  my ($self) = @_;
  my $res = q{};

  if ( $self->{config}->{common}->{output_dir} ) {
    $res .= $self->{config}->{common}->{output_dir} . q{/};
  }

  if ( $self->{config}->{plugins}->{ $self->{pname} }->{output_dir} ) {
    $res .= $self->{config}->{plugins}->{ $self->{pname} }->{output_dir} . q{/};
  }

  if ( $res =~ m{^$}xm ) {
    $res = q{./};
  }

  return $res;
}

sub _get_os {
  my ($self, $filename) = @_;

  return 'Linux-x86';
}

1;

__END__

=head1 NAME

RoPkg::Metalink::PBase

=head1 VERSION

0.2.1

=head1 SYNOPSIS

 package RoPkg::Metalink::Plugin::Fedora;

 use warnings;
 use strict;

 use vars qw($VERSION);
 $VERSION='0.1.1';

 use RoPkg::Exceptions;
 use RoPkg::Metalink::File;
 use RoPkg::Metalink::Entries;

 use English qw(-no_match_vars);
 use Scalar::Util qw(blessed);

 use RoPkg::Metalink::PBase;
 use base qw(RoPkg::Metalink::PBase);

 sub new {
   my ($class, %opt) = @_;
   my $self;
 
   $self = $class->SUPER::new(%opt);
   $self->{pname} = 'fedora';
 
   return $self;
 }
 ...

 For examples, please take a look at the source of plugins.

=head1 DESCRIPTION

This class encapsulates, all the basic functionality need by all plugins.
All specific methods must be overriden by plugins. 

=head1 SUBROUTINES/METHODS

All methods (besides new) are private. Please refer to the source for more infos.

=head2 new()

new() is the class constructor. At the moment new() requires 2 parameters:

=over 2

=item *) config - the configuration file

=item *) files_obj - a instance of RoPkg::Metalink::Files

=back

=head1 SEE ALSO

L<RoPkg::Metalink>

=head1 PERL CRITIC

This code is perl critic level 2 compliant

=head1 DIAGNOSTICS

This module has his own tests in the t directory. To run the tests, unpack
the source and use 'make test' command.

=head1 CONFIGURATION AND ENVIRONMENT

This class does not use a configuration file. No environment variables are used.

=head1 DEPENDENCIES

This class, requires:

=over 2

=item RoPkg (>= 0.5.6)

=item Scalar::Util

=back

=head1 INCOMPATIBILITIES

None known to the author

=head1 BUGS AND LIMITATIONS

No bugs known to the author. If you find a bug, or if you want to
find the updated list of bugs please refer to the http://bugs.packages.ro
website.

=head1 AUTHOR

Subredu Manuel <diablo@iasi.roedu.net>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2005 Subredu Manuel.  All Rights Reserved.
This module is free software; you can redistribute it 
and/or modify it under the same terms as Perl itself.
The LICENSE file contains the full text of the license.

=cut
