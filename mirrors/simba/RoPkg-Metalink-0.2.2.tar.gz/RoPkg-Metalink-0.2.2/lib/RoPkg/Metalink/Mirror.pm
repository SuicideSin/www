############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License v2 as published by #
## the Free Software Foundation;                                           #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink::Mirror;

use strict;
use warnings;

use RoPkg::DBObject;

use Scalar::Util qw(blessed);

use vars qw($VERSION);
use base qw(RoPkg::DBObject);

$VERSION='0.1.2';

my $pf = {
  id               => q{-},
  EntryID          => q{-},
  SponsorShortName => q{-},
  SponsorLongName  => q{-},
  SponsorWebSite   => q{-},
  BaseURL          => q{-},
  Priority         => q{-},
  CountryShort     => q{-},
  Protocol         => q{-},
};

sub new {
  my ($class, %opt) = @_;
  my $self;

  $opt{pf} = $pf;
  $self    = $class->SUPER::new(%opt);
  $self->{_sql_table} = 'Mirrors';

  return $self;
}

sub Add {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
     error    => 'Called outside class instance',
     pkg_name => 'RoPkg::Metalink::Mirror',
    );
  }

  $self->chkp(qw(EntryID Name BaseURL Country Protocol));

  return $self->SQL_Insert();
}

sub Delete {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Mirror',
    );
  }

  $self->chkp(qw(id));
  return $self->SQL_Delete(qw(id));
}

sub Update {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Mirror',
    );
  }

  $self->chkp(qw(id));

  return $self->SQL_Update(qw(id));
}

sub Load {
  my ($self) = @_;

  if ( !blessed($self) ) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink::Mirror',
    );
  }

  if (defined($self->{id})) {
    return $self->SQL_Select(qw(id));
  }

  if (defined($self->{EntryID})) {
    return $self->SQL_Select(qw(EntryID));
  }

  Param::Missing->throw(
    error    => 'Nor id not EntryID has been specified',
    pkg_name => 'RoPkg::Metalink::Mirror',
  );

  #Syntactic sugar ;)
  return 1;
}

1;


__END__

=head1 NAME

RoPkg::Metalink::Mirror

=head1 VERSION

0.1.2

=head1 SYNOPSIS

 use RoPkg::Metalink::Mirror;

 $mirror = new RoPkg::Metalink::Mirror(
            dbo        => $db,
            dbo_method => 'metalink',
          );

 $mirror->Name('test');
 $mirror->Add();

=head1 DESCRIPTION

This class is a mapper for Mirrors table from metalink generator database.

=head1 SUBROUTINES/METHODS

The following subroutines are available:

=head2 new()

The class constructor. At this moment the constructor has 2 parameters (both
of them are required). For more information about the parameters of this
method please refer to the RoPkg::DBObject man page

=head2 Add()

Add the current object to the database.

=head2 Delete()

Delete the current object from the database.

=head2 Update()

Synchronize the content of this object with the database.

=head2 Load()

Loads the object from the database. At least EntryID or id must
pe specified before calling this method, or else, a Param::Missing
exception will be raised.

=head2 id()

The id (internal) for this entry. When you add new records to the
database, please set id to 0.

=head2 EntryID()

Get/Set method . With this method you can access the entry id.

=head2 SponsorShortName()

Get/Set method. With this method you can access the short name of the sponsor of this mirror

=head2 SponsorLongName()

Get/Set method. With this method you can access the long name of the sponsor of this mirror

=head2 SponsorWebSite()

Get/Set method. With this method you can access the url to sponsor website.

=head2 BaseURL()

Get/Set method. With this method you can access the base url for this mirror.
Eg: fedora mirror on RoEduNet Iasi has: ftp.iasi.roedu.net/mirrors/fedora.redhat.com as BaseURL

=head2 Priority()

Get/Set method. With this method you can access the priority of this mirror

=head2 CountryShort()

Get/Set method. With this method you can access the short name of the country for this
mirror. Eg: for Romania CountryShort is RO

=head2 Protocol()

Get/Set method. With this method you can access the protocol used to transfer files from
this mirror.

=head1 SEE ALSO

L<RoPkg::Metalink> L<RoPkg::Metalink::Mirrors>

=head1 PERL CRITIC

This code is perl critic level 2 compliant

=head1 DIAGNOSTICS

This module has his own tests in the t directory. To run the tests, unpack
the source and use 'make test' command.

=head1 CONFIGURATION AND ENVIRONMENT

This class does not use a configuration file. No environment variables are used.

=head1 DEPENDENCIES

This class, requires:

=over 2

=item RoPkg (>= 0.5.6)

=item Scalar::Util

=back

=head1 INCOMPATIBILITIES

None known to the author

=head1 BUGS AND LIMITATIONS

No bugs known to the author. If you find a bug, or if you want to
find the updated list of bugs please refer to the http://bugs.packages.ro
website.

=head1 AUTHOR

Subredu Manuel <diablo@iasi.roedu.net>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2005 Subredu Manuel.  All Rights Reserved.
This module is free software; you can redistribute it 
and/or modify it under the same terms as Perl itself.
The LICENSE file contains the full text of the license.

=cut
