############################################################################
##      Copyright (C) 2006 Subredu Manuel                                  #
##      Author Subredu Manuel <diablo@iasi.roedu.net>                      #
##                                                                         #
## This program is free software; you can redistribute it and/or modify    #
## it under the terms of the GNU General Public License as published by    #
## the Free Software Foundation; version 2 of the License.                 #
##                                                                         #
## This program is distributed in the hope that it will be useful,         #
## but WITHOUT ANY WARRANTY; without even the implied warranty of          #
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
## GNU General Public License for more details.                            #
##                                                                         #
## You should have received a copy of the GNU General Public License       #
## along with this program; if not, write to the Free Software             #
## Foundation, Inc., 59 Temple Place - Suite 330, Boston,                  #
## MA 02111-1307,USA.                                                      #
############################################################################

package RoPkg::Metalink;

use strict;
use warnings;

use vars qw($VERSION $dbp);
$VERSION='0.2.2';

use Data::Dumper;

use English           qw(-no_match_vars);
use Scalar::Util      qw(blessed);
use Module::Pluggable instantiate => 'new';

use RoPkg::Exceptions;
use RoPkg::DB;
use RoPkg::Utils qw(CheckParam);

use RoPkg::Metalink::Entries;
use RoPkg::Metalink::Mirrors;
use RoPkg::Metalink::Files;

sub new {
  my ($class, %opt) = @_;
  my $self;

  $self = bless { %opt }, $class;
  CheckParam($self, qw(cfgFile));

  $self->_check_file($self->{cfgFile});
  $self->{cfg} = do $self->{cfgFile};

  $self->_init_db();
  $self->_init_helper_objects();

  return $self;
}

sub _check_file {
  my ($self, $filename) = @_;
  my $fh;

  if ( ! -f $filename ) {
    File::NotFound->throw(
      error    => $filename . ' not found',
      pkg_name => 'RoPkg::Metalink',
    );
  }

  if ( ! open($fh, '<', $filename) ) {
    File::Open->throw(
      error    => $filename . ' could not be opened. Please check permissions',
      pkg_name => 'RoPkg::Metalink',
    );
  }

  close($fh);
  return 1;
}

sub _check_template {
  my ($self) = @_;

  if (! $self->{cfg}->{common}->{template}) {
    File::NotFound->throw(
      error    => 'Could not find template file in configuration file',
      pkg_name => 'RoPkg::Metalink',
      filename => $self->{cfg}->{common}->{template}
    );
  }
  
  if (! -f $self->{cfg}->{common}->{template}) {
    File::NotFound->throw(
      error    => 'Could not find template file',
      pkg_name => 'RoPkg::Metalink',
      filename => $self->{cfg}->{common}->{template}
    );
  }

  return 1;
}

sub _init_db {
  my ($self) = @_;
  my $db_cfg;
  
  $db_cfg = $self->{cfg}->{db};
  $self->{db} = new RoPkg::DB();

  eval {
    $self->{db}->Add($db_cfg->{dsn}, $db_cfg->{user}, $db_cfg->{pass}, 'metalink');
  };

  if (Exception::Class->caught('DB::Connect')) {
    print $EVAL_ERROR->message,$RS;
    exit(1);
  }

  return 1;
}

sub _init_helper_objects {
  my ($self) = @_;

  $self->{entries_obj} = new RoPkg::Metalink::Entries(
                           dbo        => $self->{db},
                           dbo_method => 'db_metalink',
                         );

  $self->{mirrors_obj} = new RoPkg::Metalink::Mirrors(
                           dbo        => $self->{db},
                           dbo_method => 'db_metalink',
                         );
  
  $self->{files_obj}   = new RoPkg::Metalink::Files(
                           dbo        => $self->{db},
                           dbo_method => 'db_metalink',
                         );

  return 1;
}

sub EntryExists {
  my ($self, $entry_name) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink',
    );
  }

  return $self->{entries_obj}->Count({Name => $entry_name});
}

sub _load_entry {
  my ($self, $ename) = @_;
  my $entry;

  eval {
    ($entry) = $self->{entries_obj}->Get({ Name => $ename });
  };
  if (Exception::Class->caught('DB::NoResults')) {
    return 0;
  }
  else {
    if (ref $EVAL_ERROR) {
      $EVAL_ERROR->rethrow;
    }
  }

  return $entry;
}

sub Harvest {
  my ($self, $ename, @locations) = @_;
  my $entry;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink'
    );
  }

  if ( ! ($entry = $self->_load_entry($ename)) ) {
    print $ename, ' could not be found in database',$RS;
    return 0;
  }

  foreach($self->plugins(
             files_obj => $self->{files_obj},
             config    => $self->{cfg},
         )) {
    my $plug = $_;

    #This is a workaround for Module::Pluggable
    next if (ref($plug) =~ m{.*SUPER$}xm);
    $plug->Harvest($entry, @locations);
  }

  return 1;
}

sub Generate {
  my ($self, @entries) = @_;
  my $c = 0;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink'
    );
  }
  
  $self->_check_template();

  if ( (scalar @entries) == 0 ) {
    @entries = $self->{entries_obj}->Get();
  }

  foreach(@entries) {
    my $entry_name = $_;
    my (@mirrors, $entry);

    eval {
      ($entry) = $self->{entries_obj}->Get({Name => $entry_name});
    };

    if (Exception::Class->caught('DB::NoResults')) {
      print 'No entry with name ',$entry_name,' has been found',$RS;
      next;
    }
    else {
      if (ref($EVAL_ERROR)) {
        $EVAL_ERROR->rethrow;
      }
    }

    if ( ! $entry->Enabled ) {
      print $entry->Name,' is not enabled',$RS;
      next;
    }

    if ( $entry->InProgress ) {
      print $entry->Name,' is in progress',$RS;
      next;
    }

    @mirrors = $self->_get_mirrors_for_entry($entry);
    if ( (scalar @mirrors) == 0 ) {
      print 'Sorry. No mirrors found for this entry ',$entry->Name,$RS;
      next;
    }
   
    #call the plugins to do the actual job
    foreach($self->plugins(
              files_obj => $self->{files_obj},
              config    => $self->{cfg}
            )) {
      my $plug = $_;

      next if (ref($plug) =~ m{.*SUPER$}xm);
      $_->Generate($entry, \@mirrors);
    }
    $c++;
  }
  
  return $c;
}

sub _generate_for_entry {
  my ($self, $entry, @mirrors) = @_;

  print Dumper($entry),$RS,Dumper(@mirrors),$RS;
  return 1;
}

sub _get_mirrors_for_entry {
  my ($self, $entry) = @_;
  my (@mirrors, $mirror);

  #try to get the mirrors list for the entry
  eval {
    @mirrors = $self->{mirrors_obj}->Get({ EntryID => $entry->id });
  };

  #if no mirrors are found return a empty array
  if (Exception::Class->caught('DB::NoResults')) {
    return ();
  }
  else {
    if (ref($EVAL_ERROR)) {
      $EVAL_ERROR->rethrow();
    }
  }
  
  return @mirrors;
}

#################################
## Get objects methods - BEGIN ##
#################################
sub GetEntriesObj {
  my ($self) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink'
    );
  }

  return $self->{entries_obj};
}

sub GetMirrorsObj {
  my ($self) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink'
    );
  }

  return $self->{mirrors_obj};
}

sub GetFilesObj {
  my ($self) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink'
    );
  }

  return $self->{files_obj};
}

sub GetConfig {
  my ($self) = @_;

  if (!blessed($self)) {
    OutsideClass->throw(
      error    => 'Called outside class instance',
      pkg_name => 'RoPkg::Metalink'
    );
  }

  return $self->{cfg};
}

#################################
##  Get objects methods - END  ##
#################################

1;

__END__

=head1 NAME

RoPkg::Metalink

=head1 VERSION

0.2.2

=head1 SYNOPSIS

 use RoPkg::Metalink;

 sub main {
   my $mt = new RoPkg::Metalink(cfgFile => '/etc/mt-gen.cfg');

   $mt->Harvest('fedora');
   return 0;
 }

=head1 DESCRIPTION

RoPkg::Metalink encapsulates all the logic for generating metalink files. Basically all
you need from this module is Harvest and Generate methods. All other methods are 
not so interesting.

=head1 SUBROUTINES/METHODS

=head2 new()

The class constructor. At this moment requires only one parameter: cfgFile, the
path to the configuration file.

=head2 EntryExists($entry_name)

Returns the number of entries with name $entry_name found in database.

=head2 Harvest($entry_name, @locations)

Updates the database for $entry_name by searching all directories specified
in @locations. All new entries are added to the database, and the ones that
doesn't exists any more are removed from the database.

=head2 Generate(@entries)

Generated metalink files for all entries specified in @entries. If files already
exists, they are simply ignored.

=head2 GetEntriesObj()

Returns a instance of RoPkg::Metalink::Entries class (already initialized)

=head2 GetMirrorsObj()

Returns a instance of RoPkg::Metalink::Mirrors class (already initialized)

=head2 GetFilesObj()

Returns a instance of RoPkg::Metalink::Files class (already initialized)

=head2 GetConfig()

Returns the configuration (as read from the configuration file)

=head1 SEE ALSO

L<RoPkg::Metalink>
L<RoPkg::Metalink::Entry> L<RoPkg::Metalink::Entries>
L<RoPkg::Metalink::Mirror> L<RoPkg::Metalink::Mirrors>
L<RoPkg::Metalink::File> L<RoPkg::Metalink::Files>
L<RoPkg::Metalink::PBase>

=head1 PERL CRITIC

This code is perl critic level 2 compliant

=head1 DIAGNOSTICS

This module has his own tests in the t directory. To run the tests, unpack
the source and use 'make test' command.

=head1 CONFIGURATION AND ENVIRONMENT

This class use a configuration file. No environment variables are used.

=head1 DEPENDENCIES

This class, requires:

=over 2

=item RoPkg (>= 0.5.6)

=item Scalar::Util

=back

For all hashes to be generated you need bitcolider available from
http://sourceforge.net/projects/bitcollider/ . Please note that bitcolider
does not know how to deal with files bigger than 2GB.

=head1 INCOMPATIBILITIES

None known to the author

=head1 BUGS AND LIMITATIONS

No bugs known to the author. If you find a bug, or if you want to
find the updated list of bugs please refer to the http://bugs.packages.ro
website.
 Currently only files smaller than 2GB have all the hashes. Files greater than
2GB will have only md5.

=head1 AUTHOR

Subredu Manuel <diablo@iasi.roedu.net>

=head1 LICENSE AND COPYRIGHT

Copyright (C) 2005 Subredu Manuel.  All Rights Reserved.
This module is free software; you can redistribute it 
and/or modify it under the same terms as Perl itself.
The LICENSE file contains the full text of the license.

=cut
